(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(require('./errors'));
  } else {
    root.ORBIT = root.ORBIT || {};
    root.ORBIT.providers = factory(root.ORBIT.errors);
  }
})(typeof self !== 'undefined' ? self : this, function (errors) {
  'use strict';

  var REGISTRY = [
    {
      id: 'openai',
      name: 'OpenAI',
      requestStyle: 'openai-chat-completions',
      auth: 'bearer',
      streaming: 'server-sent-events',
      defaultEndpoint: 'https://api.openai.com/v1',
      note: 'Chat Completions and the Responses API are different contracts. A later adapter must pin one.'
    },
    {
      id: 'anthropic',
      name: 'Anthropic',
      requestStyle: 'anthropic-messages',
      auth: 'x-api-key',
      streaming: 'anthropic-sse',
      defaultEndpoint: 'https://api.anthropic.com',
      note: 'Not OpenAI-compatible. Messages require an anthropic-version header and a different body.'
    },
    {
      id: 'gemini',
      name: 'Google Gemini',
      requestStyle: 'gemini-generate-content',
      auth: 'api-key-header-or-query',
      streaming: 'gemini-stream-generate-content',
      defaultEndpoint: 'https://generativelanguage.googleapis.com',
      note: 'Uses generateContent, not the OpenAI chat schema. Tool calling differs as well.'
    },
    {
      id: 'openrouter',
      name: 'OpenRouter',
      requestStyle: 'openai-compatible-chat',
      auth: 'bearer',
      streaming: 'server-sent-events',
      defaultEndpoint: 'https://openrouter.ai/api/v1',
      note: 'OpenAI-like, but model ids, routing headers, and error bodies are provider-specific.'
    },
    {
      id: 'custom',
      name: 'Custom OpenAI-compatible',
      requestStyle: 'openai-compatible-chat',
      auth: 'bearer-or-custom',
      streaming: 'unknown-until-configured',
      defaultEndpoint: '',
      note: 'An endpoint alone does not prove compatibility. Streaming and tool calls must be detected, not assumed.'
    }
  ];

  function listProviders() {
    return REGISTRY.map(function (item) {
      return Object.assign({}, item);
    });
  }

  function getProvider(id) {
    for (var i = 0; i < REGISTRY.length; i++) {
      if (REGISTRY[i].id === id) return Object.assign({}, REGISTRY[i]);
    }
    return null;
  }

  function createAdapter(providerId) {
    var provider = getProvider(providerId);
    if (!provider) {
      return {
        providerId: providerId,
        implemented: false,
        send: function () {
          return Promise.reject(errors.createError(
            'UNKNOWN_PROVIDER',
            'Unknown provider. No request was sent.'
          ));
        }
      };
    }
    var target = provider.defaultEndpoint || 'a custom endpoint';
    return {
      providerId: provider.id,
      implemented: false,
      send: function () {
        return Promise.reject(errors.createError(
          'ADAPTER_NOT_IMPLEMENTED',
          provider.name + ' has no request adapter in Milestone 1. No request was sent to ' + target + '.'
        ));
      }
    };
  }

  return {
    listProviders: listProviders,
    getProvider: getProvider,
    createAdapter: createAdapter
  };
});
